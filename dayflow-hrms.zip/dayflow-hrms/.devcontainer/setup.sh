#!/usr/bin/env bash
set -e

echo "Installing backend dependencies..."
cd backend
cp -n .env.example .env || true
npm install

echo "Installing frontend dependencies..."
cd ../frontend
cp -n .env.example .env || true
npm install

echo "Setup complete. See README.md for how to run the app."
