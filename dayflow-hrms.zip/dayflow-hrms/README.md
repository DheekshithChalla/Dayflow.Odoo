# Dayflow — Human Resource Management System

A starter implementation of the Dayflow HRMS requirements: auth, role-based
dashboards, profile management, attendance, leave/time-off, and payroll
visibility.

**Stack:** Node.js/Express + SQLite (Sequelize) backend, React (Vite) frontend.
SQLite is used so there's no external database to set up — it just works in
a fresh Codespace.

## Folder structure

```
dayflow-hrms/
├── backend/          Express API (auth, employees, attendance, leave, payroll)
├── frontend/          React app (Vite)
└── .devcontainer/     Auto-installs dependencies when you open in Codespaces
```

## Option A — Run in GitHub Codespaces (recommended)

1. Unzip this project and push it to a new GitHub repo:
   ```bash
   unzip dayflow-hrms.zip
   cd dayflow-hrms
   git init
   git add .
   git commit -m "Initial Dayflow HRMS scaffold"
   git branch -M main
   git remote add origin https://github.com/<your-username>/<your-repo>.git
   git push -u origin main
   ```
2. On GitHub, go to your repo → **Code** → **Codespaces** → **Create codespace on main**.
3. Wait for the container to build — the `.devcontainer/setup.sh` script runs
   automatically and installs both `backend` and `frontend` dependencies.
4. Open **two terminals** in the Codespace:

   **Terminal 1 — backend:**
   ```bash
   cd backend
   npm run seed     # creates demo admin + employee accounts
   npm run dev       # starts the API on port 5000
   ```

   **Terminal 2 — frontend:**
   ```bash
   cd frontend
   npm run dev        # starts the app on port 5173
   ```
5. Codespaces will pop up a notification that port `5173` is forwarded —
   click **Open in Browser**. If it doesn't, go to the **Ports** tab and open
   port `5173` manually.

6. Sign in with the seeded demo accounts:
   - **Admin:** `admin@dayflow.com` / `Admin@123`
   - **Employee:** `employee@dayflow.com` / `Employee@123`

   Or click **Sign up** to register a new account.

## Option B — Run locally (no Codespaces)

Requires Node.js 18+.

```bash
# Backend
cd backend
cp .env.example .env
npm install
npm run seed
npm run dev            # http://localhost:5000

# In a second terminal — Frontend
cd frontend
cp .env.example .env
npm install
npm run dev             # http://localhost:5173
```

## What's implemented vs. what's stubbed

| Feature (from spec)              | Status |
|-----------------------------------|--------|
| Sign up / sign in (JWT auth)      | ✅ Implemented |
| Role-based access (Admin/Employee)| ✅ Implemented |
| Employee dashboard                | ✅ Implemented |
| Admin dashboard                   | ✅ Implemented |
| Profile view/edit                 | ✅ Implemented |
| Attendance check-in/out + history | ✅ Implemented |
| Leave apply/approve/reject        | ✅ Implemented (approving leave auto-marks attendance as "Leave" for that date range) |
| Payroll view (employee read-only, admin edit) | ✅ Implemented |
| Analytics & reports (attendance summaries, leave breakdowns, salary slips) | ✅ Implemented — `/api/reports` route with `attendance-summary`, `leave-summary`, and `salary-slip` endpoints, plus a Reports page (date-range filters for admin, printable slip for everyone) |
| Email verification                | ⚠️ Stubbed — accounts are auto-verified on signup. Wiring real email requires a provider (e.g. SendGrid, Resend, or Nodemailer + SMTP) and isn't included here to avoid requiring API keys. |
| Email/notification alerts         | ⚠️ Not implemented — same reason (needs a mail/notification provider) |
| Excalidraw wireframes             | Referenced in the original doc — not something code can consume automatically; use it as a visual reference while building out UI polish |

### Reports & Analytics details

- `GET /api/reports/attendance-summary?from=YYYY-MM-DD&to=YYYY-MM-DD` (admin only) — per-employee counts of Present/Absent/Half-day/Leave in the range.
- `GET /api/reports/leave-summary?from=&to=` (admin only) — totals by leave status and by leave type.
- `GET /api/reports/salary-slip?month=YYYY-MM` — an employee's own slip; admins can also pass `/salary-slip/:userId`. Computes monthly gross from annual salary, deducts a prorated amount for unapproved absences, and returns net pay. The Reports page has a **Print** button for a paper copy.

This is intentionally simple (no charts library, no PDF generation) so it has zero extra dependencies — see "Next steps" below for how to extend it.

## Next steps to extend this

- **Charts**: the Reports page currently shows tables — swap in a charting
  library (e.g. `recharts`) for visual attendance/leave trends.
- **PDF salary slips**: the salary slip is currently a printable HTML view;
  generate an actual PDF server-side (e.g. `pdfkit`) for downloadable slips.
- **Email**: add `nodemailer` + a transactional email provider for real
  verification emails and leave-approval notifications.
- **Validation**: the current forms do minimal validation — consider adding
  `zod` or `joi` on the backend and matching client-side checks.
- **Password reset flow**: not in the original spec's functional
  requirements list, but a natural addition next to sign up/sign in.
- **Deployment**: the backend can deploy as-is to Render/Railway/Fly.io;
  swap SQLite for Postgres in production by changing `backend/config/db.js`.

## Troubleshooting

- **Port already in use**: change `PORT` in `backend/.env` or the Vite port
  in `frontend/vite.config.js`.
- **CORS errors**: confirm `VITE_API_URL` in `frontend/.env` matches where
  the backend is actually running (check the forwarded port URL in
  Codespaces, not just `localhost`, if you're calling the API directly from
  the browser via its public forwarded URL).
- **"Cannot find module" on first run**: you skipped `npm install` in that
  folder — Codespaces does this automatically via `.devcontainer/setup.sh`,
  but locally you need to run it yourself in both `backend/` and `frontend/`.
