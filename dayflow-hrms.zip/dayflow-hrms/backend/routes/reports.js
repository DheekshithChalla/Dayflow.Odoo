const express = require("express");
const { Op, fn, col } = require("sequelize");
const Attendance = require("../models/Attendance");
const LeaveRequest = require("../models/LeaveRequest");
const User = require("../models/User");
const { protect, adminOnly } = require("../middleware/auth");

const router = express.Router();

function defaultRange(req) {
  const to = req.query.to || new Date().toISOString().slice(0, 10);
  const from =
    req.query.from ||
    new Date(new Date(to).setDate(new Date(to).getDate() - 30))
      .toISOString()
      .slice(0, 10);
  return { from, to };
}

// Admin: attendance summary per employee over a date range
// Counts of Present / Absent / Half-day / Leave
router.get("/attendance-summary", protect, adminOnly, async (req, res) => {
  const { from, to } = defaultRange(req);

  const rows = await Attendance.findAll({
    where: { date: { [Op.between]: [from, to] } },
    include: [{ model: User, attributes: ["id", "name", "employeeId", "department"] }],
  });

  const summary = {};
  for (const r of rows) {
    const key = r.userId;
    if (!summary[key]) {
      summary[key] = {
        userId: key,
        name: r.User?.name,
        employeeId: r.User?.employeeId,
        department: r.User?.department,
        Present: 0,
        Absent: 0,
        "Half-day": 0,
        Leave: 0,
      };
    }
    summary[key][r.status] = (summary[key][r.status] || 0) + 1;
  }

  res.json({ from, to, rows: Object.values(summary) });
});

// Admin: leave summary — counts by status and by type, over a date range
router.get("/leave-summary", protect, adminOnly, async (req, res) => {
  const { from, to } = defaultRange(req);

  const leaves = await LeaveRequest.findAll({
    where: { startDate: { [Op.between]: [from, to] } },
  });

  const byStatus = { Pending: 0, Approved: 0, Rejected: 0 };
  const byType = { Paid: 0, Sick: 0, Unpaid: 0 };
  for (const l of leaves) {
    byStatus[l.status] = (byStatus[l.status] || 0) + 1;
    byType[l.leaveType] = (byType[l.leaveType] || 0) + 1;
  }

  res.json({ from, to, total: leaves.length, byStatus, byType });
});

// Salary slip for a given month — employee can fetch their own, admin can fetch anyone's
router.get("/salary-slip/:userId?", protect, async (req, res) => {
  const targetId = req.params.userId || req.user.id;

  if (String(targetId) !== String(req.user.id) && req.user.role !== "admin") {
    return res.status(403).json({ message: "Not authorized to view this slip" });
  }

  const user = await User.findByPk(targetId, {
    attributes: ["id", "name", "employeeId", "jobTitle", "department", "salary"],
  });
  if (!user) return res.status(404).json({ message: "Employee not found" });

  const month = req.query.month || new Date().toISOString().slice(0, 7); // YYYY-MM
  const [year, mon] = month.split("-");
  const from = `${year}-${mon}-01`;
  const to = new Date(year, Number(mon), 0).toISOString().slice(0, 10); // last day of month

  const leaveDays = await Attendance.count({
    where: { userId: targetId, date: { [Op.between]: [from, to] }, status: "Leave" },
  });
  const absentDays = await Attendance.count({
    where: { userId: targetId, date: { [Op.between]: [from, to] }, status: "Absent" },
  });

  const monthlyGross = (user.salary || 0) / 12;
  // Simple illustrative deduction: unpaid-equivalent days (absences) prorated off monthly gross.
  const daysInMonth = new Date(year, Number(mon), 0).getDate();
  const deduction = (monthlyGross / daysInMonth) * absentDays;
  const netPay = Math.max(monthlyGross - deduction, 0);

  res.json({
    employee: {
      name: user.name,
      employeeId: user.employeeId,
      jobTitle: user.jobTitle,
      department: user.department,
    },
    month,
    annualSalary: user.salary || 0,
    monthlyGross: Math.round(monthlyGross * 100) / 100,
    leaveDaysTaken: leaveDays,
    absentDays,
    deduction: Math.round(deduction * 100) / 100,
    netPay: Math.round(netPay * 100) / 100,
  });
});

module.exports = router;
