const express = require("express");
const { Op } = require("sequelize");
const Attendance = require("../models/Attendance");
const { protect, adminOnly } = require("../middleware/auth");

const router = express.Router();

// 3.4.1 Check-in
router.post("/checkin", protect, async (req, res) => {
  const today = new Date().toISOString().slice(0, 10);
  const time = new Date().toTimeString().slice(0, 8);

  let record = await Attendance.findOne({
    where: { userId: req.user.id, date: today },
  });
  if (record) {
    return res.status(400).json({ message: "Already checked in today" });
  }
  record = await Attendance.create({
    userId: req.user.id,
    date: today,
    status: "Present",
    checkIn: time,
  });
  res.status(201).json(record);
});

// 3.4.1 Check-out
router.post("/checkout", protect, async (req, res) => {
  const today = new Date().toISOString().slice(0, 10);
  const time = new Date().toTimeString().slice(0, 8);

  const record = await Attendance.findOne({
    where: { userId: req.user.id, date: today },
  });
  if (!record) {
    return res.status(400).json({ message: "No check-in found for today" });
  }
  await record.update({ checkOut: time });
  res.json(record);
});

// 3.4.2 Employee: view own attendance (daily/weekly range via query params)
router.get("/me", protect, async (req, res) => {
  const { from, to } = req.query;
  const where = { userId: req.user.id };
  if (from && to) where.date = { [Op.between]: [from, to] };

  const records = await Attendance.findAll({
    where,
    order: [["date", "DESC"]],
  });
  res.json(records);
});

// 3.4.2 Admin: view attendance of all employees (optionally filter by userId)
router.get("/", protect, adminOnly, async (req, res) => {
  const { userId, from, to } = req.query;
  const where = {};
  if (userId) where.userId = userId;
  if (from && to) where.date = { [Op.between]: [from, to] };

  const records = await Attendance.findAll({
    where,
    order: [["date", "DESC"]],
  });
  res.json(records);
});

module.exports = router;
