const express = require("express");
const User = require("../models/User");
const { protect, adminOnly } = require("../middleware/auth");

const router = express.Router();

// 3.3.1 View own profile
router.get("/me", protect, async (req, res) => {
  const user = await User.findByPk(req.user.id, {
    attributes: { exclude: ["password"] },
  });
  res.json(user);
});

// 3.3.2 Edit own profile (limited fields: phone, address, profilePicture)
router.put("/me", protect, async (req, res) => {
  const { phone, address, profilePicture } = req.body;
  const user = await User.findByPk(req.user.id);
  await user.update({ phone, address, profilePicture });
  res.json({ message: "Profile updated" });
});

// 3.2.2 Admin: list all employees
router.get("/", protect, adminOnly, async (req, res) => {
  const users = await User.findAll({ attributes: { exclude: ["password"] } });
  res.json(users);
});

// Admin: view any single employee
router.get("/:id", protect, adminOnly, async (req, res) => {
  const user = await User.findByPk(req.params.id, {
    attributes: { exclude: ["password"] },
  });
  if (!user) return res.status(404).json({ message: "Not found" });
  res.json(user);
});

// Admin: edit any employee (all fields, incl. salary/job details)
router.put("/:id", protect, adminOnly, async (req, res) => {
  const user = await User.findByPk(req.params.id);
  if (!user) return res.status(404).json({ message: "Not found" });
  const { name, phone, address, jobTitle, department, salary, profilePicture } =
    req.body;
  await user.update({
    name,
    phone,
    address,
    jobTitle,
    department,
    salary,
    profilePicture,
  });
  res.json({ message: "Employee updated" });
});

module.exports = router;
