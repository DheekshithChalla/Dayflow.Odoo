const express = require("express");
const User = require("../models/User");
const { protect, adminOnly } = require("../middleware/auth");

const router = express.Router();

// 3.6.1 Employee: read-only payroll view
router.get("/me", protect, async (req, res) => {
  const user = await User.findByPk(req.user.id, {
    attributes: ["id", "name", "employeeId", "jobTitle", "department", "salary"],
  });
  res.json(user);
});

// 3.6.2 Admin: view payroll of all employees
router.get("/", protect, adminOnly, async (req, res) => {
  const users = await User.findAll({
    attributes: ["id", "name", "employeeId", "jobTitle", "department", "salary"],
  });
  res.json(users);
});

// 3.6.2 Admin: update salary structure
router.put("/:id", protect, adminOnly, async (req, res) => {
  const { salary } = req.body;
  const user = await User.findByPk(req.params.id);
  if (!user) return res.status(404).json({ message: "Not found" });
  await user.update({ salary });
  res.json({ message: "Salary updated", salary: user.salary });
});

module.exports = router;
