const { Sequelize } = require("sequelize");
const path = require("path");

// SQLite file lives at backend/data/dayflow.sqlite
// No external DB server needed — works out of the box in Codespaces.
const sequelize = new Sequelize({
  dialect: "sqlite",
  storage: path.join(__dirname, "..", "data", "dayflow.sqlite"),
  logging: false,
});

module.exports = sequelize;
