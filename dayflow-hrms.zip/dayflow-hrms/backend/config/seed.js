require("dotenv").config();
const bcrypt = require("bcryptjs");
const sequelize = require("./db");
const User = require("../models/User");
require("../models/Attendance");
require("../models/LeaveRequest");

async function seed() {
  await sequelize.sync();

  const adminPass = await bcrypt.hash("Admin@123", 10);
  const empPass = await bcrypt.hash("Employee@123", 10);

  await User.findOrCreate({
    where: { email: "admin@dayflow.com" },
    defaults: {
      employeeId: "ADM001",
      name: "Admin User",
      email: "admin@dayflow.com",
      password: adminPass,
      role: "admin",
      isEmailVerified: true,
      jobTitle: "HR Officer",
      department: "Human Resources",
      salary: 90000,
    },
  });

  await User.findOrCreate({
    where: { email: "employee@dayflow.com" },
    defaults: {
      employeeId: "EMP001",
      name: "Sample Employee",
      email: "employee@dayflow.com",
      password: empPass,
      role: "employee",
      isEmailVerified: true,
      jobTitle: "Software Engineer",
      department: "Engineering",
      salary: 60000,
    },
  });

  console.log("Seed complete.");
  console.log("Admin login:    admin@dayflow.com / Admin@123");
  console.log("Employee login: employee@dayflow.com / Employee@123");
  process.exit(0);
}

seed().catch((err) => {
  console.error(err);
  process.exit(1);
});
