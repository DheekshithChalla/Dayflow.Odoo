require("dotenv").config();
const express = require("express");
const cors = require("cors");
const sequelize = require("./config/db");

const authRoutes = require("./routes/auth");
const employeeRoutes = require("./routes/employees");
const attendanceRoutes = require("./routes/attendance");
const leaveRoutes = require("./routes/leave");
const payrollRoutes = require("./routes/payroll");
const reportsRoutes = require("./routes/reports");

// Load all models so Sequelize knows about them before sync()
require("./models/User");
require("./models/Attendance");
require("./models/LeaveRequest");

const app = express();

app.use(cors());
app.use(express.json());

app.get("/api/health", (req, res) => res.json({ status: "ok" }));

app.use("/api/auth", authRoutes);
app.use("/api/employees", employeeRoutes);
app.use("/api/attendance", attendanceRoutes);
app.use("/api/leave", leaveRoutes);
app.use("/api/payroll", payrollRoutes);
app.use("/api/reports", reportsRoutes);

const PORT = process.env.PORT || 5000;

sequelize
  .sync() // creates dayflow.sqlite + tables automatically if missing
  .then(() => {
    app.listen(PORT, () =>
      console.log(`Dayflow API running on http://localhost:${PORT}`)
    );
  })
  .catch((err) => console.error("DB sync failed:", err));
