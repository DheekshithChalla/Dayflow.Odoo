const { DataTypes } = require("sequelize");
const sequelize = require("../config/db");
const User = require("./User");

const LeaveRequest = sequelize.define("LeaveRequest", {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  leaveType: {
    type: DataTypes.ENUM("Paid", "Sick", "Unpaid"),
    allowNull: false,
  },
  startDate: {
    type: DataTypes.DATEONLY,
    allowNull: false,
  },
  endDate: {
    type: DataTypes.DATEONLY,
    allowNull: false,
  },
  remarks: DataTypes.STRING,
  status: {
    type: DataTypes.ENUM("Pending", "Approved", "Rejected"),
    defaultValue: "Pending",
  },
  adminComment: DataTypes.STRING,
});

LeaveRequest.belongsTo(User, { foreignKey: "userId", onDelete: "CASCADE" });
User.hasMany(LeaveRequest, { foreignKey: "userId" });

module.exports = LeaveRequest;
