const { DataTypes } = require("sequelize");
const sequelize = require("../config/db");
const User = require("./User");

const Attendance = sequelize.define("Attendance", {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  date: {
    type: DataTypes.DATEONLY,
    allowNull: false,
  },
  status: {
    type: DataTypes.ENUM("Present", "Absent", "Half-day", "Leave"),
    defaultValue: "Present",
  },
  checkIn: DataTypes.TIME,
  checkOut: DataTypes.TIME,
});

Attendance.belongsTo(User, { foreignKey: "userId", onDelete: "CASCADE" });
User.hasMany(Attendance, { foreignKey: "userId" });

module.exports = Attendance;
