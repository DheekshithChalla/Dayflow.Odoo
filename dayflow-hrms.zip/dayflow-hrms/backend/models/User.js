const { DataTypes } = require("sequelize");
const sequelize = require("../config/db");

const User = sequelize.define("User", {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  employeeId: {
    type: DataTypes.STRING,
    unique: true,
    allowNull: false,
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  email: {
    type: DataTypes.STRING,
    unique: true,
    allowNull: false,
    validate: { isEmail: true },
  },
  password: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  role: {
    type: DataTypes.ENUM("admin", "employee"),
    defaultValue: "employee",
  },
  isEmailVerified: {
    type: DataTypes.BOOLEAN,
    defaultValue: false,
  },
  // 3.3 Employee Profile Management fields
  phone: DataTypes.STRING,
  address: DataTypes.STRING,
  jobTitle: DataTypes.STRING,
  department: DataTypes.STRING,
  profilePicture: DataTypes.STRING,
  // 3.6 Payroll
  salary: {
    type: DataTypes.FLOAT,
    defaultValue: 0,
  },
});

module.exports = User;
