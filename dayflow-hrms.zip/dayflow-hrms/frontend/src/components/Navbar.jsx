import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  return (
    <nav>
      <div>
        <strong>Dayflow</strong>
        {user && (
          <>
            <Link to="/dashboard" style={{ marginLeft: 20 }}>Dashboard</Link>
            <Link to="/profile">Profile</Link>
            <Link to="/attendance">Attendance</Link>
            <Link to="/leave">Leave</Link>
            <Link to="/payroll">Payroll</Link>
            <Link to="/reports">Reports</Link>
          </>
        )}
      </div>
      <div>
        {user ? (
          <button
            className="secondary"
            onClick={() => {
              logout();
              navigate("/signin");
            }}
          >
            Logout ({user.name})
          </button>
        ) : (
          <Link to="/signin">Sign In</Link>
        )}
      </div>
    </nav>
  );
}
