import { useEffect, useState } from "react";
import api from "../api/axios";
import { useAuth } from "../context/AuthContext";

export default function Leave() {
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";
  const [leaves, setLeaves] = useState([]);
  const [form, setForm] = useState({ leaveType: "Paid", startDate: "", endDate: "", remarks: "" });
  const [error, setError] = useState("");

  async function load() {
    const res = await api.get(isAdmin ? "/leave" : "/leave/me");
    setLeaves(res.data);
  }

  useEffect(() => {
    load();
  }, [isAdmin]);

  async function submitLeave(e) {
    e.preventDefault();
    setError("");
    try {
      await api.post("/leave", form);
      setForm({ leaveType: "Paid", startDate: "", endDate: "", remarks: "" });
      load();
    } catch (err) {
      setError(err.response?.data?.message || "Failed to submit leave");
    }
  }

  async function decide(id, status) {
    const adminComment = window.prompt(`Comment for ${status.toLowerCase()} (optional):`) || "";
    await api.put(`/leave/${id}/status`, { status, adminComment });
    load();
  }

  return (
    <div>
      <h2>Leave & Time-Off</h2>
      {error && <div className="error">{error}</div>}

      {!isAdmin && (
        <div className="card">
          <h3>Apply for Leave</h3>
          <form onSubmit={submitLeave}>
            <label>Leave Type</label>
            <select value={form.leaveType} onChange={(e) => setForm({ ...form, leaveType: e.target.value })}>
              <option value="Paid">Paid</option>
              <option value="Sick">Sick</option>
              <option value="Unpaid">Unpaid</option>
            </select>
            <label>Start Date</label>
            <input type="date" value={form.startDate} onChange={(e) => setForm({ ...form, startDate: e.target.value })} required />
            <label>End Date</label>
            <input type="date" value={form.endDate} onChange={(e) => setForm({ ...form, endDate: e.target.value })} required />
            <label>Remarks</label>
            <textarea value={form.remarks} onChange={(e) => setForm({ ...form, remarks: e.target.value })} rows={3} />
            <button type="submit">Submit Request</button>
          </form>
        </div>
      )}

      <div className="card">
        <h3>{isAdmin ? "All Leave Requests" : "My Leave Requests"}</h3>
        <table>
          <thead>
            <tr>
              {isAdmin && <th>Employee</th>}
              <th>Type</th><th>From</th><th>To</th><th>Status</th><th>Remarks</th>
              {isAdmin && <th>Actions</th>}
            </tr>
          </thead>
          <tbody>
            {leaves.map((l) => (
              <tr key={l.id}>
                {isAdmin && <td>{l.User?.name} ({l.User?.employeeId})</td>}
                <td>{l.leaveType}</td>
                <td>{l.startDate}</td>
                <td>{l.endDate}</td>
                <td><span className={`badge ${l.status}`}>{l.status}</span></td>
                <td>{l.remarks || "-"}</td>
                {isAdmin && (
                  <td>
                    {l.status === "Pending" ? (
                      <>
                        <button onClick={() => decide(l.id, "Approved")} style={{ marginRight: 6 }}>Approve</button>
                        <button onClick={() => decide(l.id, "Rejected")} className="danger">Reject</button>
                      </>
                    ) : (
                      <span style={{ color: "#999" }}>{l.adminComment || "-"}</span>
                    )}
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
