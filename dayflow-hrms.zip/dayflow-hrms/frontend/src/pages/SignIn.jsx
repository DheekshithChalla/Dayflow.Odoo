import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function SignIn() {
  const { signin } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    try {
      await signin(email, password);
      navigate("/dashboard");
    } catch (err) {
      setError(err.response?.data?.message || "Sign in failed");
    }
  }

  return (
    <div className="card" style={{ maxWidth: 400, margin: "40px auto" }}>
      <h2>Sign In</h2>
      {error && <div className="error">{error}</div>}
      <form onSubmit={handleSubmit}>
        <label>Email</label>
        <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
        <label>Password</label>
        <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
        <button type="submit">Sign In</button>
      </form>
      <p style={{ marginTop: 12 }}>
        No account? <Link to="/signup">Sign up</Link>
      </p>
      <p style={{ fontSize: 13, color: "#666" }}>
        Demo: admin@dayflow.com / Admin@123 &middot; employee@dayflow.com / Employee@123
      </p>
    </div>
  );
}
