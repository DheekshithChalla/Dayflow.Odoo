import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function EmployeeDashboard() {
  const { user } = useAuth();

  const cards = [
    { to: "/profile", label: "Profile", desc: "View & edit your details" },
    { to: "/attendance", label: "Attendance", desc: "Check in/out, view history" },
    { to: "/leave", label: "Leave Requests", desc: "Apply for time off" },
    { to: "/payroll", label: "Payroll", desc: "View salary (read-only)" },
    { to: "/reports", label: "Salary Slip", desc: "View & print your monthly slip" },
  ];

  return (
    <div>
      <h2>Welcome, {user?.name}</h2>
      <div className="grid">
        {cards.map((c) => (
          <Link key={c.to} to={c.to} className="card" style={{ textDecoration: "none", color: "inherit" }}>
            <h3>{c.label}</h3>
            <p style={{ color: "#666", fontSize: 14 }}>{c.desc}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
