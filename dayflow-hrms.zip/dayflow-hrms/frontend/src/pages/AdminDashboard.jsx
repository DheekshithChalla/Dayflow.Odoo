import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "../api/axios";

export default function AdminDashboard() {
  const [employees, setEmployees] = useState([]);
  const [leaves, setLeaves] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    async function load() {
      try {
        const [empRes, leaveRes] = await Promise.all([
          api.get("/employees"),
          api.get("/leave"),
        ]);
        setEmployees(empRes.data);
        setLeaves(leaveRes.data);
      } catch (err) {
        setError(err.response?.data?.message || "Failed to load dashboard");
      }
    }
    load();
  }, []);

  const pending = leaves.filter((l) => l.status === "Pending");

  return (
    <div>
      <h2>Admin / HR Dashboard</h2>
      {error && <div className="error">{error}</div>}
      <div className="grid">
        <div className="card">
          <h3>Employees</h3>
          <p style={{ fontSize: 28, margin: 0 }}>{employees.length}</p>
        </div>
        <div className="card">
          <h3>Pending Leave Approvals</h3>
          <p style={{ fontSize: 28, margin: 0 }}>{pending.length}</p>
        </div>
        <Link to="/reports" className="card" style={{ textDecoration: "none", color: "inherit" }}>
          <h3>Reports & Analytics</h3>
          <p style={{ color: "#666", fontSize: 14, margin: 0 }}>
            Attendance summaries, leave breakdowns, salary slips
          </p>
        </Link>
      </div>

      <div className="card">
        <h3>Employee List</h3>
        <table>
          <thead>
            <tr><th>Employee ID</th><th>Name</th><th>Department</th><th>Job Title</th></tr>
          </thead>
          <tbody>
            {employees.map((e) => (
              <tr key={e.id}>
                <td>{e.employeeId}</td>
                <td>{e.name}</td>
                <td>{e.department || "-"}</td>
                <td>{e.jobTitle || "-"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
