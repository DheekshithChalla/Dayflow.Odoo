import { useEffect, useState } from "react";
import api from "../api/axios";
import { useAuth } from "../context/AuthContext";

export default function Profile() {
  const { user } = useAuth();
  const [profile, setProfile] = useState(null);
  const [form, setForm] = useState({ phone: "", address: "", profilePicture: "" });
  const [message, setMessage] = useState("");

  useEffect(() => {
    api.get("/employees/me").then((res) => {
      setProfile(res.data);
      setForm({
        phone: res.data.phone || "",
        address: res.data.address || "",
        profilePicture: res.data.profilePicture || "",
      });
    });
  }, []);

  async function handleSave(e) {
    e.preventDefault();
    await api.put("/employees/me", form);
    setMessage("Profile updated.");
  }

  if (!profile) return <p>Loading...</p>;

  return (
    <div className="card" style={{ maxWidth: 500 }}>
      <h2>My Profile</h2>
      <p><strong>Employee ID:</strong> {profile.employeeId}</p>
      <p><strong>Name:</strong> {profile.name}</p>
      <p><strong>Email:</strong> {profile.email}</p>
      <p><strong>Job Title:</strong> {profile.jobTitle || "-"}</p>
      <p><strong>Department:</strong> {profile.department || "-"}</p>

      <h3>Editable Details</h3>
      {message && <div style={{ color: "#059669", marginBottom: 10 }}>{message}</div>}
      <form onSubmit={handleSave}>
        <label>Phone</label>
        <input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
        <label>Address</label>
        <input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
        <label>Profile Picture URL</label>
        <input value={form.profilePicture} onChange={(e) => setForm({ ...form, profilePicture: e.target.value })} />
        <button type="submit">Save Changes</button>
      </form>
    </div>
  );
}
