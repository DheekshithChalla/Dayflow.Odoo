import { useEffect, useState } from "react";
import api from "../api/axios";
import { useAuth } from "../context/AuthContext";

function todayMinus(days) {
  const d = new Date();
  d.setDate(d.getDate() - days);
  return d.toISOString().slice(0, 10);
}

export default function Reports() {
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";

  const [from, setFrom] = useState(todayMinus(30));
  const [to, setTo] = useState(todayMinus(0));
  const [attendanceSummary, setAttendanceSummary] = useState([]);
  const [leaveSummary, setLeaveSummary] = useState(null);
  const [month, setMonth] = useState(new Date().toISOString().slice(0, 7));
  const [slip, setSlip] = useState(null);
  const [error, setError] = useState("");

  async function loadAdminReports() {
    try {
      const [attRes, leaveRes] = await Promise.all([
        api.get("/reports/attendance-summary", { params: { from, to } }),
        api.get("/reports/leave-summary", { params: { from, to } }),
      ]);
      setAttendanceSummary(attRes.data.rows);
      setLeaveSummary(leaveRes.data);
    } catch (err) {
      setError(err.response?.data?.message || "Failed to load reports");
    }
  }

  async function loadSlip() {
    try {
      const res = await api.get("/reports/salary-slip", { params: { month } });
      setSlip(res.data);
    } catch (err) {
      setError(err.response?.data?.message || "Failed to load salary slip");
    }
  }

  useEffect(() => {
    if (isAdmin) loadAdminReports();
    loadSlip();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div>
      <h2>Reports & Analytics</h2>
      {error && <div className="error">{error}</div>}

      {isAdmin && (
        <div className="card">
          <h3>Date Range</h3>
          <div style={{ display: "flex", gap: 12, alignItems: "flex-end", flexWrap: "wrap" }}>
            <div>
              <label>From</label>
              <input type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
            </div>
            <div>
              <label>To</label>
              <input type="date" value={to} onChange={(e) => setTo(e.target.value)} />
            </div>
            <button onClick={loadAdminReports} style={{ marginBottom: 12 }}>
              Refresh
            </button>
          </div>
        </div>
      )}

      {isAdmin && leaveSummary && (
        <div className="card">
          <h3>Leave Summary</h3>
          <div className="grid">
            <div>
              <strong>By Status</strong>
              <table>
                <tbody>
                  {Object.entries(leaveSummary.byStatus).map(([k, v]) => (
                    <tr key={k}><td>{k}</td><td>{v}</td></tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div>
              <strong>By Type</strong>
              <table>
                <tbody>
                  {Object.entries(leaveSummary.byType).map(([k, v]) => (
                    <tr key={k}><td>{k}</td><td>{v}</td></tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
          <p style={{ color: "#666", fontSize: 13 }}>
            {leaveSummary.total} total leave request(s) starting in this range.
          </p>
        </div>
      )}

      {isAdmin && (
        <div className="card">
          <h3>Attendance Summary by Employee</h3>
          <table>
            <thead>
              <tr>
                <th>Employee</th><th>Department</th>
                <th>Present</th><th>Absent</th><th>Half-day</th><th>Leave</th>
              </tr>
            </thead>
            <tbody>
              {attendanceSummary.map((r) => (
                <tr key={r.userId}>
                  <td>{r.name} ({r.employeeId})</td>
                  <td>{r.department || "-"}</td>
                  <td>{r.Present}</td>
                  <td>{r.Absent}</td>
                  <td>{r["Half-day"]}</td>
                  <td>{r.Leave}</td>
                </tr>
              ))}
              {attendanceSummary.length === 0 && (
                <tr><td colSpan={6} style={{ color: "#999" }}>No records in this range.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      )}

      <div className="card" style={{ maxWidth: 500 }}>
        <h3>Salary Slip {isAdmin ? "(yours)" : ""}</h3>
        <div style={{ display: "flex", gap: 10, alignItems: "flex-end", marginBottom: 12 }}>
          <div>
            <label>Month</label>
            <input type="month" value={month} onChange={(e) => setMonth(e.target.value)} />
          </div>
          <button onClick={loadSlip} style={{ marginBottom: 12 }}>Load</button>
          {slip && <button onClick={() => window.print()} className="secondary" style={{ marginBottom: 12 }}>Print</button>}
        </div>

        {slip && (
          <div>
            <p><strong>{slip.employee.name}</strong> ({slip.employee.employeeId})</p>
            <p style={{ color: "#666", fontSize: 13 }}>
              {slip.employee.jobTitle || "-"} &middot; {slip.employee.department || "-"}
            </p>
            <table>
              <tbody>
                <tr><td>Month</td><td>{slip.month}</td></tr>
                <tr><td>Annual Salary</td><td>{slip.annualSalary.toLocaleString()}</td></tr>
                <tr><td>Monthly Gross</td><td>{slip.monthlyGross.toLocaleString()}</td></tr>
                <tr><td>Leave Days Taken</td><td>{slip.leaveDaysTaken}</td></tr>
                <tr><td>Absent Days</td><td>{slip.absentDays}</td></tr>
                <tr><td>Deduction</td><td>-{slip.deduction.toLocaleString()}</td></tr>
                <tr><td><strong>Net Pay</strong></td><td><strong>{slip.netPay.toLocaleString()}</strong></td></tr>
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
