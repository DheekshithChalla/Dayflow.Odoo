import { useEffect, useState } from "react";
import api from "../api/axios";

export default function Attendance() {
  const [records, setRecords] = useState([]);
  const [error, setError] = useState("");

  async function load() {
    const res = await api.get("/attendance/me");
    setRecords(res.data);
  }

  useEffect(() => {
    load();
  }, []);

  async function checkIn() {
    setError("");
    try {
      await api.post("/attendance/checkin");
      load();
    } catch (err) {
      setError(err.response?.data?.message || "Check-in failed");
    }
  }

  async function checkOut() {
    setError("");
    try {
      await api.post("/attendance/checkout");
      load();
    } catch (err) {
      setError(err.response?.data?.message || "Check-out failed");
    }
  }

  return (
    <div>
      <h2>Attendance</h2>
      {error && <div className="error">{error}</div>}
      <div className="card">
        <button onClick={checkIn} style={{ marginRight: 10 }}>Check In</button>
        <button onClick={checkOut} className="secondary">Check Out</button>
      </div>
      <div className="card">
        <h3>History</h3>
        <table>
          <thead>
            <tr><th>Date</th><th>Status</th><th>Check In</th><th>Check Out</th></tr>
          </thead>
          <tbody>
            {records.map((r) => (
              <tr key={r.id}>
                <td>{r.date}</td>
                <td><span className={`badge ${r.status}`}>{r.status}</span></td>
                <td>{r.checkIn || "-"}</td>
                <td>{r.checkOut || "-"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
