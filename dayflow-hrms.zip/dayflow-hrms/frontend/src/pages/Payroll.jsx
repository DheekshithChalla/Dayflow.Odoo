import { useEffect, useState } from "react";
import api from "../api/axios";
import { useAuth } from "../context/AuthContext";

export default function Payroll() {
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";
  const [data, setData] = useState(isAdmin ? [] : null);

  async function load() {
    const res = await api.get(isAdmin ? "/payroll" : "/payroll/me");
    setData(res.data);
  }

  useEffect(() => {
    load();
  }, [isAdmin]);

  async function updateSalary(id, current) {
    const value = window.prompt("New salary:", current);
    if (value === null) return;
    await api.put(`/payroll/${id}`, { salary: Number(value) });
    load();
  }

  if (!data) return <p>Loading...</p>;

  if (!isAdmin) {
    return (
      <div className="card" style={{ maxWidth: 500 }}>
        <h2>Payroll (Read-only)</h2>
        <p><strong>Name:</strong> {data.name}</p>
        <p><strong>Job Title:</strong> {data.jobTitle || "-"}</p>
        <p><strong>Department:</strong> {data.department || "-"}</p>
        <p><strong>Salary:</strong> {data.salary?.toLocaleString()} / year</p>
      </div>
    );
  }

  return (
    <div className="card">
      <h2>Payroll — All Employees</h2>
      <table>
        <thead>
          <tr><th>Employee</th><th>Job Title</th><th>Department</th><th>Salary</th><th></th></tr>
        </thead>
        <tbody>
          {data.map((e) => (
            <tr key={e.id}>
              <td>{e.name} ({e.employeeId})</td>
              <td>{e.jobTitle || "-"}</td>
              <td>{e.department || "-"}</td>
              <td>{e.salary?.toLocaleString()}</td>
              <td><button onClick={() => updateSalary(e.id, e.salary)}>Edit</button></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
