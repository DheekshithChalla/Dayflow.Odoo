# Dayflow — Human Resource Management System

A starter implementation of the Dayflow HRMS requirements: auth, role-based
dashboards, profile management, attendance, leave/time-off, and payroll
visibility.

**Stack:** Node.js/Express + SQLite (Sequelize) backend, React (Vite) frontend.
SQLite is used so there's no external database to set up — it just works in
a fresh Codespace.

## Folder structure

```
dayflow-hrms/
├── backend/          Express API (auth, employees, attendance, leave, payroll)
├── frontend/          React app (Vite)
└── .devcontainer/     Auto-installs dependencies when you open in Codespaces
```

## Option A — Run in GitHub Codespaces (recommended)

1. Unzip this project and push it to a new GitHub repo:
   ```bash
   unzip dayflow-hrms.zip
   cd dayflow-hrms
   git init
   git add .
   git commit -m "Initial Dayflow HRMS scaffold"
   git branch -M main
   git remote add origin https://github.com/<your-username>/<your-repo>.git
   git push -u origin main
   ```
2. On GitHub, go to your repo → **Code** → **Codespaces** → **Create codespace on main**.
3. Wait for the container to build — the `.devcontainer/setup.sh` script runs
   automatically and installs both `backend` and `frontend` dependencies.
4. Open **two terminals** in the Codespace:

   **Terminal 1 — backend:**
   ```bash
   cd backend
   npm run seed     # creates demo admin + employee accounts
   npm run dev       # starts the API on port 5000
   ```

   **Terminal 2 — frontend:**
   ```bash
   cd frontend
   npm run dev        # starts the app on port 5173
   ```
5. Codespaces will pop up a notification that port `5173` is forwarded —
   click **Open in Browser**. If it doesn't, go to the **Ports** tab and open
   port `5173` manually.

6. Sign in with the seeded demo accounts:
   - **Admin:** `admin@dayflow.com` / `Admin@123`
   - **Employee:** `employee@dayflow.com` / `Employee@123`

   Or click **Sign up** to register a new account.

## Option B — Run locally (no Codespaces)

Requires Node.js 18+.

```bash
# Backend
cd backend
cp .env.example .env
npm install
npm run seed
npm run dev            # http://localhost:5000

# In a second terminal — Frontend
cd frontend
cp .env.example .env
npm install
npm run dev             # http://localhost:5173
```

## What's implemented vs. what's stubbed

| Feature (from spec)              | Status |
|-----------------------------------|--------|
| Sign up / sign in (JWT auth)      | ✅ Implemented |
| Role-based access (Admin/Employee)| ✅ Implemented |
| Employee dashboard                | ✅ Implemented |
| Admin dashboard                   | ✅ Implemented |
| Profile view/edit                 | ✅ Implemented |
| Attendance check-in/out + history | ✅ Implemented |
| Leave apply/approve/reject        | ✅ Implemented (approving leave auto-marks attendance as "Leave" for that date range) |
| Payroll view (employee read-only, admin edit) | ✅ Implemented |
| Analytics & reports (attendance summaries, leave breakdowns, salary slips) | ✅ Implemented — `/api/reports` route with `attendance-summary`, `leave-summary`, and `salary-slip` endpoints, plus a Reports page (date-range filters for admin, printable slip for everyone) |
| Email verification                | ✅ Implemented — signup sends a real verification email; `/verify-email/:token` activates the account; unverified users see a "resend" banner |
| Email/notification alerts         | ✅ Implemented — approving/rejecting a leave request emails the employee |
| Excalidraw wireframes             | Referenced in the original doc — not something code can consume automatically; use it as a visual reference while building out UI polish |

### Email details — how it works out of the box

No API keys or accounts needed to try this: if `SMTP_HOST` isn't set in
`backend/.env`, the backend auto-creates a free **Ethereal** test account on
first use. Ethereal doesn't deliver to real inboxes — instead, every send
returns a **preview URL** where you can see the actual email that would have
gone out. The app surfaces that link directly in the UI:

- After signup, the confirmation screen links straight to the verification email.
- The "please verify your email" banner's **Resend** button does the same.
- When an admin approves/rejects a leave request, an alert shows the notification-email preview link.

To send real email instead, set `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`,
`SMTP_PASS`, and `SMTP_FROM` in `backend/.env` (commented-out examples are
in `.env.example`) — any SMTP-speaking provider works (SendGrid, Resend,
Gmail SMTP, etc). No code changes needed; `backend/utils/email.js` switches
automatically based on whether those variables are set.

**Note:** Ethereal's servers need outbound internet access. This is fine in
a normal GitHub Codespace (full internet access) — I just couldn't fully
verify email delivery from the sandbox this project was built in, since
that sandbox only allows a fixed list of domains (npm, GitHub, PyPI, etc).
Everything else — token generation, storage, the verify endpoint, and
graceful fallback if sending fails — was tested and confirmed working.

### Reports & Analytics details

- `GET /api/reports/attendance-summary?from=YYYY-MM-DD&to=YYYY-MM-DD` (admin only) — per-employee counts of Present/Absent/Half-day/Leave in the range.
- `GET /api/reports/leave-summary?from=&to=` (admin only) — totals by leave status and by leave type.
- `GET /api/reports/salary-slip?month=YYYY-MM` — an employee's own slip; admins can also pass `/salary-slip/:userId`. Computes monthly gross from annual salary, deducts a prorated amount for unapproved absences, and returns net pay. The Reports page has a **Print** button for a paper copy.

This is intentionally simple (no charts library, no PDF generation) so it has zero extra dependencies — see "Next steps" below for how to extend it.

## Next steps to extend this

- **Charts**: the Reports page currently shows tables — swap in a charting
  library (e.g. `recharts`) for visual attendance/leave trends.
- **PDF salary slips**: the salary slip is currently a printable HTML view;
  generate an actual PDF server-side (e.g. `pdfkit`) for downloadable slips.
- **Token expiry on verification links**: `emailVerificationToken` currently
  never expires — add a `emailVerificationTokenExpiry` column if you want
  links to time out.
- **Validation**: the current forms do minimal validation — consider adding
  `zod` or `joi` on the backend and matching client-side checks.
- **Password reset flow**: not in the original spec's functional
  requirements list, but a natural addition next to sign up/sign in.
- **Deployment**: the backend can deploy as-is to Render/Railway/Fly.io;
  swap SQLite for Postgres in production by changing `backend/config/db.js`.

## Troubleshooting

- **Port already in use**: change `PORT` in `backend/.env` or the Vite port
  in `frontend/vite.config.js`.
- **CORS errors**: confirm `VITE_API_URL` in `frontend/.env` matches where
  the backend is actually running (check the forwarded port URL in
  Codespaces, not just `localhost`, if you're calling the API directly from
  the browser via its public forwarded URL).
- **"Cannot find module" on first run**: you skipped `npm install` in that
  folder — Codespaces does this automatically via `.devcontainer/setup.sh`,
  but locally you need to run it yourself in both `backend/` and `frontend/`.
