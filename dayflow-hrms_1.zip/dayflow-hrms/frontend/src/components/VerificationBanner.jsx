import { useState } from "react";
import api from "../api/axios";
import { useAuth } from "../context/AuthContext";

export default function VerificationBanner() {
  const { user } = useAuth();
  const [sent, setSent] = useState(false);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [error, setError] = useState("");

  if (!user || user.isEmailVerified) return null;

  async function resend() {
    setError("");
    try {
      const { data } = await api.post("/auth/resend-verification", { email: user.email });
      setSent(true);
      setPreviewUrl(data.emailPreviewUrl);
    } catch (err) {
      setError(err.response?.data?.message || "Failed to resend");
    }
  }

  return (
    <div className="card" style={{ background: "#fffbeb", border: "1px solid #fde68a" }}>
      <strong>Please verify your email.</strong> Check your inbox for a link, or{" "}
      <button onClick={resend} style={{ marginLeft: 8 }}>Resend verification email</button>
      {sent && (
        <p style={{ marginTop: 8, fontSize: 13 }}>
          Sent. {previewUrl && (
            <>
              (Demo mode — no real inbox: <a href={previewUrl} target="_blank" rel="noreferrer">view the email here</a>.)
            </>
          )}
        </p>
      )}
      {error && <div className="error">{error}</div>}
    </div>
  );
}
