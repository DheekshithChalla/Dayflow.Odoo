import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function SignUp() {
  const { signup } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({
    employeeId: "",
    name: "",
    email: "",
    password: "",
    role: "employee",
  });
  const [error, setError] = useState("");
  const [previewUrl, setPreviewUrl] = useState(null);

  function update(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    try {
      const data = await signup(form);
      if (data.emailPreviewUrl) {
        setPreviewUrl(data.emailPreviewUrl);
      } else {
        navigate("/dashboard");
      }
    } catch (err) {
      setError(err.response?.data?.message || "Sign up failed");
    }
  }

  return (
    <div className="card" style={{ maxWidth: 400, margin: "40px auto" }}>
      <h2>Sign Up</h2>
      {error && <div className="error">{error}</div>}
      {previewUrl ? (
        <div>
          <p>Account created! We sent a verification email.</p>
          <p style={{ fontSize: 13, color: "#666" }}>
            Demo mode — this is a test inbox, not a real one:{" "}
            <a href={previewUrl} target="_blank" rel="noreferrer">view the verification email here</a>.
          </p>
          <button onClick={() => navigate("/dashboard")} style={{ marginTop: 12 }}>
            Continue to Dashboard
          </button>
        </div>
      ) : (
        <>
          <form onSubmit={handleSubmit}>
            <label>Employee ID</label>
            <input value={form.employeeId} onChange={(e) => update("employeeId", e.target.value)} required />
            <label>Full Name</label>
            <input value={form.name} onChange={(e) => update("name", e.target.value)} required />
            <label>Email</label>
            <input type="email" value={form.email} onChange={(e) => update("email", e.target.value)} required />
            <label>Password</label>
            <input type="password" value={form.password} onChange={(e) => update("password", e.target.value)} required />
            <label>Role</label>
            <select value={form.role} onChange={(e) => update("role", e.target.value)}>
              <option value="employee">Employee</option>
              <option value="admin">HR / Admin</option>
            </select>
            <button type="submit">Create Account</button>
          </form>
          <p style={{ marginTop: 12 }}>
            Already have an account? <Link to="/signin">Sign in</Link>
          </p>
        </>
      )}
    </div>
  );
}
