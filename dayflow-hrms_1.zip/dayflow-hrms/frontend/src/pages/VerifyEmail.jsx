import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import api from "../api/axios";

export default function VerifyEmail() {
  const { token } = useParams();
  const [status, setStatus] = useState("verifying"); // verifying | success | error
  const [message, setMessage] = useState("");

  useEffect(() => {
    api
      .get(`/auth/verify-email/${token}`)
      .then(() => setStatus("success"))
      .catch((err) => {
        setStatus("error");
        setMessage(err.response?.data?.message || "Verification failed");
      });
  }, [token]);

  return (
    <div className="card" style={{ maxWidth: 420, margin: "40px auto", textAlign: "center" }}>
      {status === "verifying" && <p>Verifying your email...</p>}
      {status === "success" && (
        <>
          <h2>✅ Email verified</h2>
          <p>Your account is fully activated.</p>
          <Link to="/dashboard"><button>Go to Dashboard</button></Link>
        </>
      )}
      {status === "error" && (
        <>
          <h2>Verification failed</h2>
          <p className="error">{message}</p>
          <Link to="/dashboard"><button className="secondary">Back to Dashboard</button></Link>
        </>
      )}
    </div>
  );
}
