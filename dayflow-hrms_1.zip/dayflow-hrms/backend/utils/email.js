const nodemailer = require("nodemailer");

// Lazily-created transporter, cached across calls.
let transporterPromise = null;

/**
 * Returns a nodemailer transporter.
 *
 * - If SMTP_HOST/SMTP_USER/SMTP_PASS are set in .env, uses that real
 *   provider (SendGrid, Resend, Gmail SMTP, etc — anything that speaks SMTP).
 * - Otherwise, auto-creates a free Ethereal test account on first use.
 *   Ethereal never delivers real mail — it just captures it and gives you
 *   a preview URL, which is perfect for demoing this flow with zero setup.
 */
function getTransporter() {
  if (transporterPromise) return transporterPromise;

  if (process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS) {
    transporterPromise = Promise.resolve(
      nodemailer.createTransport({
        host: process.env.SMTP_HOST,
        port: Number(process.env.SMTP_PORT) || 587,
        secure: false,
        auth: {
          user: process.env.SMTP_USER,
          pass: process.env.SMTP_PASS,
        },
      })
    );
    return transporterPromise;
  }

  transporterPromise = nodemailer.createTestAccount().then((testAccount) =>
    nodemailer.createTransport({
      host: "smtp.ethereal.email",
      port: 587,
      secure: false,
      auth: {
        user: testAccount.user,
        pass: testAccount.pass,
      },
    })
  );
  return transporterPromise;
}

/**
 * Sends an email. Returns the message info, including a `previewUrl`
 * when running in Ethereal test mode (undefined when using real SMTP).
 */
async function sendEmail({ to, subject, html }) {
  const transporter = await getTransporter();
  const info = await transporter.sendMail({
    from: process.env.SMTP_FROM || '"Dayflow HRMS" <no-reply@dayflow.local>',
    to,
    subject,
    html,
  });

  const previewUrl = nodemailer.getTestMessageUrl(info) || undefined;
  if (previewUrl) {
    // In test mode there's no real inbox — log the preview link so it's
    // easy to find during development/demo.
    console.log(`[email] "${subject}" to ${to} — preview: ${previewUrl}`);
  }
  return { ...info, previewUrl };
}

module.exports = { sendEmail };
