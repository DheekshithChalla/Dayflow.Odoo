const express = require("express");
const crypto = require("crypto");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const User = require("../models/User");
const { sendEmail } = require("../utils/email");

const router = express.Router();

function signToken(user) {
  return jwt.sign(
    { id: user.id, role: user.role, email: user.email },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || "7d" }
  );
}

// 3.1.1 Sign Up
router.post("/signup", async (req, res) => {
  try {
    const { employeeId, name, email, password, role } = req.body;

    if (!employeeId || !name || !email || !password) {
      return res.status(400).json({ message: "All fields are required" });
    }

    // Basic password security rule
    if (password.length < 6) {
      return res
        .status(400)
        .json({ message: "Password must be at least 6 characters" });
    }

    const existing = await User.findOne({ where: { email } });
    if (existing) {
      return res.status(409).json({ message: "Email already registered" });
    }

    const hashed = await bcrypt.hash(password, 10);
    const emailVerificationToken = crypto.randomBytes(24).toString("hex");

    const user = await User.create({
      employeeId,
      name,
      email,
      password: hashed,
      role: role === "admin" ? "admin" : "employee",
      isEmailVerified: false,
      emailVerificationToken,
    });

    const verifyUrl = `${process.env.APP_URL || "http://localhost:5173"}/verify-email/${emailVerificationToken}`;
    let previewUrl;
    try {
      const info = await sendEmail({
        to: user.email,
        subject: "Verify your Dayflow account",
        html: `<p>Hi ${user.name},</p>
               <p>Welcome to Dayflow. Please verify your email to activate your account:</p>
               <p><a href="${verifyUrl}">${verifyUrl}</a></p>`,
      });
      previewUrl = info.previewUrl;
    } catch (mailErr) {
      // Don't block signup if email sending fails — log and continue.
      console.error("Failed to send verification email:", mailErr.message);
    }

    // The account can still sign in — isEmailVerified just gates nothing
    // functionally here (per spec it's a signup step), but the frontend
    // shows a "please verify" banner until they click the link.
    const token = signToken(user);
    res.status(201).json({
      token,
      user: {
        id: user.id,
        employeeId: user.employeeId,
        name: user.name,
        email: user.email,
        role: user.role,
        isEmailVerified: user.isEmailVerified,
      },
      // Only present in Ethereal test mode — lets the demo "see" the email.
      emailPreviewUrl: previewUrl,
    });
  } catch (err) {
    res.status(500).json({ message: "Signup failed", error: err.message });
  }
});

// 3.1.2 Sign In
router.post("/signin", async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ where: { email } });
    if (!user) {
      return res.status(401).json({ message: "Invalid email or password" });
    }

    const match = await bcrypt.compare(password, user.password);
    if (!match) {
      return res.status(401).json({ message: "Invalid email or password" });
    }

    const token = signToken(user);
    res.json({
      token,
      user: {
        id: user.id,
        employeeId: user.employeeId,
        name: user.name,
        email: user.email,
        role: user.role,
        isEmailVerified: user.isEmailVerified,
      },
    });
  } catch (err) {
    res.status(500).json({ message: "Signin failed", error: err.message });
  }
});

// Verify email via token from the emailed link
router.get("/verify-email/:token", async (req, res) => {
  const user = await User.findOne({
    where: { emailVerificationToken: req.params.token },
  });
  if (!user) {
    return res.status(400).json({ message: "Invalid or expired verification link" });
  }
  await user.update({ isEmailVerified: true, emailVerificationToken: null });
  res.json({ message: "Email verified successfully" });
});

// Resend verification email (for users who missed/lost the first one)
router.post("/resend-verification", async (req, res) => {
  const { email } = req.body;
  const user = await User.findOne({ where: { email } });
  if (!user) return res.status(404).json({ message: "No account with that email" });
  if (user.isEmailVerified) {
    return res.status(400).json({ message: "Email already verified" });
  }

  const token = crypto.randomBytes(24).toString("hex");
  await user.update({ emailVerificationToken: token });

  const verifyUrl = `${process.env.APP_URL || "http://localhost:5173"}/verify-email/${token}`;
  const info = await sendEmail({
    to: user.email,
    subject: "Verify your Dayflow account",
    html: `<p>Hi ${user.name},</p><p><a href="${verifyUrl}">${verifyUrl}</a></p>`,
  });

  res.json({ message: "Verification email sent", emailPreviewUrl: info.previewUrl });
});

module.exports = router;
