const express = require("express");
const LeaveRequest = require("../models/LeaveRequest");
const Attendance = require("../models/Attendance");
const User = require("../models/User");
const { protect, adminOnly } = require("../middleware/auth");
const { sendEmail } = require("../utils/email");

const router = express.Router();

// 3.5.1 Employee: apply for leave
router.post("/", protect, async (req, res) => {
  const { leaveType, startDate, endDate, remarks } = req.body;
  if (!leaveType || !startDate || !endDate) {
    return res.status(400).json({ message: "Missing required fields" });
  }
  const leave = await LeaveRequest.create({
    userId: req.user.id,
    leaveType,
    startDate,
    endDate,
    remarks,
  });
  res.status(201).json(leave);
});

// Employee: view own leave requests
router.get("/me", protect, async (req, res) => {
  const leaves = await LeaveRequest.findAll({
    where: { userId: req.user.id },
    order: [["createdAt", "DESC"]],
  });
  res.json(leaves);
});

// 3.5.2 Admin: view all leave requests
router.get("/", protect, adminOnly, async (req, res) => {
  const leaves = await LeaveRequest.findAll({
    include: [{ model: User, attributes: ["id", "name", "employeeId"] }],
    order: [["createdAt", "DESC"]],
  });
  res.json(leaves);
});

// 3.5.2 Admin: approve/reject leave, with comment
router.put("/:id/status", protect, adminOnly, async (req, res) => {
  const { status, adminComment } = req.body; // "Approved" | "Rejected"
  if (!["Approved", "Rejected"].includes(status)) {
    return res.status(400).json({ message: "Invalid status" });
  }

  const leave = await LeaveRequest.findByPk(req.params.id);
  if (!leave) return res.status(404).json({ message: "Not found" });

  await leave.update({ status, adminComment });

  // 3.5.2 "Changes reflect immediately in employee records" — also notify
  // the employee by email that a decision was made.
  const employee = await User.findByPk(leave.userId);
  if (employee) {
    let previewUrl;
    try {
      const info = await sendEmail({
        to: employee.email,
        subject: `Your ${leave.leaveType} leave request was ${status.toLowerCase()}`,
        html: `<p>Hi ${employee.name},</p>
               <p>Your leave request (${leave.startDate} to ${leave.endDate}) has been
               <strong>${status.toLowerCase()}</strong>.</p>
               ${adminComment ? `<p>Comment: ${adminComment}</p>` : ""}`,
      });
      previewUrl = info.previewUrl;
    } catch (mailErr) {
      console.error("Failed to send leave decision email:", mailErr.message);
    }
    res.locals.emailPreviewUrl = previewUrl;
  }

  // Reflect approved leave into attendance records for the date range
  if (status === "Approved") {
    const start = new Date(leave.startDate);
    const end = new Date(leave.endDate);
    for (
      let d = new Date(start);
      d <= end;
      d.setDate(d.getDate() + 1)
    ) {
      const dateStr = d.toISOString().slice(0, 10);
      const [record] = await Attendance.findOrCreate({
        where: { userId: leave.userId, date: dateStr },
        defaults: { status: "Leave" },
      });
      if (record.status !== "Leave") {
        await record.update({ status: "Leave" });
      }
    }
  }

  res.json({
    message: `Leave ${status.toLowerCase()}`,
    leave,
    emailPreviewUrl: res.locals.emailPreviewUrl,
  });
});

module.exports = router;
